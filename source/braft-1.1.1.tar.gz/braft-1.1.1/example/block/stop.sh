#!/bin/bash

killall -9 block_server
